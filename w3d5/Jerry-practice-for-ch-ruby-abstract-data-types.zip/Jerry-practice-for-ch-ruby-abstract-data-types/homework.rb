class Stack

    def initialize
      # create ivar to store stack here!
      @ivar = []
    end

    def push(el)
      # adds an element to the stack
      @ivar.unshift(el)
    end

    def pop
      # removes one element from the stack
      @ivar.shift
    end

    def peek
      # returns, but doesn't remove, the top element in the stack
      @ivar[0]
    end

end

class Queue

    def initialize
        @ivar = []
    end

    def enqueue(el)
        @ivar.unshift(el)
    end

    def dequeue
        @ivar.pop
    end

    def peek
        @ivar[-1]
    end
end

class Map

    def initialize

        @ivar = Array.new(){Array.new(2)}
    end

    def set(key, val)
        @ivar.each do |subset|
            if subset[0] == key
                subset[1] = val
                return true
            end
        end
        @ivar << [key, val]
    end

    def get(key)
        @ivar.each{|subset| return subset[1] if subset[0] == key}
    end

    def delete(key)
        @ivar.each_with_index do |subset, i|
            if subset[0] == key
                @ivar.delete_at(i)
            end
        end

    end

    def show
        @ivar
    end

end
